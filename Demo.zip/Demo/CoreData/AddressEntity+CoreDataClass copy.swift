//
//  AddressEntity+CoreDataClass.swift
//  
//
//  Created by Neosoft on 08/09/23.
//
//

import Foundation
import CoreData
import UIKit

@objc(AddressEntity)
public class AddressEntity: NSManagedObject {

}
