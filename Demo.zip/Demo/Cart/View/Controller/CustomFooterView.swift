//
//  CustomFooterView.swift
//  Demo
//
//  Created by Shraddha Ghadage on 05/09/2023.
//

import UIKit


class CustomFooterView: UITableViewHeaderFooterView {
    @IBOutlet weak var orderNowButton: UIButton!

    @IBOutlet weak var totalAmount: UILabel!
    
}
