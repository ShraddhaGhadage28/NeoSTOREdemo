//
//  AddressFooterView.swift
//  Demo
//
//  Created by Neosoft on 12/09/23.
//

import UIKit

class AddressFooterView: UITableViewHeaderFooterView {


    @IBOutlet weak var placeOrder: UIButton!
    
}
