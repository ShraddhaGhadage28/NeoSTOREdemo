//
//  AddressEntity+CoreDataClass.swift
//  
//
//  Created by Neosoft on 08/09/23.
//
//

import Foundation
import CoreData

@objc(AddressEntity)
public class AddressEntity: NSManagedObject {

}
