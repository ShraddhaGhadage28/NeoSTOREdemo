//
//  ViewDesign.swift
//  NeoStore
//
//  Created by Shraddha Ghadage on 09/08/2023.
//

import UIKit

class ViewDesign: UIView {
     func setUpUI() {
                layer.borderWidth = 1.0
                layer.borderColor = UIColor.white.cgColor
                
            }
}
