//
//  ErrorMessages.swift
//  NeoStore
//
//  Created by Shraddha Ghadage on 10/08/2023.
//

import Foundation

struct Register {
    static let message = "Registration is unsuccessful. Email id already exist"
    static let userMsg = "Email id already exist"
}
