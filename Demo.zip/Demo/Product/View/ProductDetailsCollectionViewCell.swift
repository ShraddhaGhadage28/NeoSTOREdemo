//
//  CollectionViewCell.swift
//  NeoStore
//
//  Created by Shraddha Ghadage on 25/08/2023.
//

import UIKit

class ProductDetailsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
