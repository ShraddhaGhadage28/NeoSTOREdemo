//
//  OrderIdFooterView.swift
//  Demo
//
//  Created by Neosoft on 13/09/23.
//

import UIKit

class OrderIdFooterView: UITableViewHeaderFooterView {

   
    @IBOutlet weak var totalCost: UILabel!
    
}
